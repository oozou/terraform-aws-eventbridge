def handler(event, context):
    print(f'Event: {event}')
    print(f'Context: {context}')
